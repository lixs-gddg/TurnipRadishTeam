#ifndef __GOINGTO_H__
#define __GOINGTO_H__
const double accerlate_va=19.6488;
const double accerlate_vb=14.1647;
const double accerlate_aa=38.8124;
const double accerlate_ab=20.1705;


void goingto(int robotId,int workplaceId);


#endif